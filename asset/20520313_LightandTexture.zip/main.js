import * as THREE from 'three';
import { LinearMipmapLinearFilter } from 'three';
// import { GUI } from 'dat.gui';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';


//Hàm khởi tạo các phần tử
function init() {
    var scene = new THREE.Scene();
    var gui = new dat.GUI()
    var clock = new THREE.Clock();
    var loader = new THREE.TextureLoader()
    
    //Điều chỉnh camera
    var camera = new THREE.PerspectiveCamera( 45, 
        window.innerWidth / window.innerHeight, 
        1, 1000 
    );
    
    var cameraZPosition = new THREE.Group();
    var cameraYPosition = new THREE.Group();
    var cameraYRotation = new THREE.Group();
    var cameraXRotation = new THREE.Group();
    var cameraZRotation = new THREE.Group();
    

    cameraYPosition.name = 'YPos';
    cameraZPosition.name = 'ZPos';
    cameraYRotation.name = 'YRot';
    cameraXRotation.name = 'XRot';  
    cameraZRotation.name = 'ZRot';  
    
    cameraZRotation.add(camera);
    cameraYPosition.add(cameraZRotation);
    cameraZPosition.add(cameraYPosition);
    cameraXRotation.add(cameraZPosition);
    cameraYRotation.add(cameraXRotation);
    scene.add(cameraYRotation);

    cameraYRotation.rotation.y = 3;
    cameraXRotation.rotation.x = 6;
    cameraZPosition.position.z = 20;
    

    // var camera = new THREE.OrthographicCamera( 
    //     -15,15,15,-15,
    //     1,1000
    // );
    // camera.position.x= 1;
    // camera.position.y = 2;
    // camera.position.z = 5;

    // camera.lookAt(new THREE.Vector3(0,0,0));

    var renderer = new THREE.WebGLRenderer();
    renderer.setSize( window.innerWidth, window.innerHeight );
    renderer.setClearColor(0x51a5dd);
    renderer.shadowMap.enabled = true;
    document.body.appendChild( renderer.domElement );
    

    
    //Điều chỉnh độ gradient
    var enableFog = false;
    if (enableFog) {
        scene.fog = new THREE.FogExp2(0xffffff,0.2);
    }

    //Cho phép điều chỉnh xoay góc nhìn
    var controls = new OrbitControls( camera, renderer.domElement );
    
    //Khởi tạo các phần tử
    // var box = getBox(1,1,1);
    var plane = getPlane (30);
    var light = getPointLight();
    
    var sphere = getSphere(0.1);
    var boxGrid = getBoxGrid(8 , 1.05);
    // var helper = new THREE.CameraHelper(light.shadow.camera);

    //Đặt tên
    boxGrid.name = 'boxGrid8'
    plane.name = 'plane-1';
    
    // box.position.y = box.geometry.parameters.height/2;
    
    // box.position.set(0,0,-0.5);
    
    //Set các tham số mặc định
    light.position.y = 1.75;
    plane.rotation.x = Math.PI/2;
    camera.position.set(15,15,-15);

    //Đưa các phần tử vào màn hình
    scene.add(plane);
    light.add(sphere);
    scene.add(boxGrid);
    scene.add(light);
    // scene.add(helper);

    //Tạo texture cho các vật thể
    plane.material.map = loader.load('grass2.jpg');
    // var texture = plane.material.map;
    // texture.wrapS = THREE.RepeatWrapping;
    // texture.wrapT = THREE.RepeatWrapping;
    // texture.repeat.set(1.5,1.5);


    // Add gui for light
    var lightFolder = gui.addFolder('LIGHT')
    lightFolder.add(light,'intensity',0,5);
    lightFolder.add(light.position,'x',0,5);
    lightFolder.add(light.position,'y',0,20)
    lightFolder.add(light.position,'z',0,20);
    // lightFolder.add(light,'penumbra',0,1);
    
    // Add gui for camera
    var cameraFolder = gui.addFolder('CAMERA')
    cameraFolder.add(cameraZPosition.position,'z',0,50)
    cameraFolder.add(cameraYRotation.rotation,'y',-Math.PI,Math.PI)
    cameraFolder.add(cameraXRotation.rotation,'x',-Math.PI,Math.PI)
    

    update(renderer,scene,camera,controls,clock);
   

}

function getPointLight() {
    var light = new THREE.PointLight(0xffffff,1);
    light.castShadow = true;
    return light;
}

function getSpotLight() {
    var light = new THREE.SpotLight(0xffffff,1);
    light.castShadow = true;
    light.shadow.bias = 0.001;
    light.shadow.mapSize.width = 596;

    return light;
}

function getDirectionalLight() {
    var light = new THREE.DirectionalLight(0xffffff,0.5);
    light.castShadow = true;
    light.shadow.camera.left = -5;
    light.shadow.camera.right = 5;
    // light.shadow.camera.top = 5;
    // light.shadow.camera.bottom = -5;
    return light;
}

function getAmbientLight() {
    var light = new THREE.AmbientLight(0xffffff,1);
    return light;
}

function getBox (w,h,d,c) {
    var geometry = new THREE.BoxGeometry( w, h, d );
    var material = new THREE.MeshPhongMaterial( {color: c} );
    var mesh = new THREE.Mesh( geometry, material );
    mesh.castShadow = true;
    return mesh;
}

function getPlane (size) {
    var geometry = new THREE.PlaneGeometry( size,size);
    var material = new THREE.MeshPhongMaterial( { color: '#32CD32', side:THREE.DoubleSide} );
    
    var mesh = new THREE.Mesh( geometry, material );
    mesh.receiveShadow = true;
    return mesh;
}

function getSphere (size) {
    var geometry = new THREE.SphereGeometry( size,20,20);
    var material = new THREE.MeshBasicMaterial( { color: 0xffdc00, side:THREE.DoubleSide} );
    
    var mesh = new THREE.Mesh( geometry, material );
    return mesh;
}   

function getBoxGrid(amount, separationMultiplier){
    var group = new THREE.Group();
    for (var i=0; i<amount; i++){
        var obj;
        if (i%2 != 0)
            obj = getBox(1,1,1,0x993300);
        else obj = getBox(1,1,1,0xffffff);
        obj.castShadow = true;
        obj.position.x = i*separationMultiplier;
        obj.position.y = obj.geometry.parameters.height/2;
        group.add(obj);
        for (var j=1; j<amount; j++){
            
            if ((i % 2 != 0) && (j % 2 == 0) || (j % 2 != 0) && (i % 2 == 0))
                obj = getBox(1,1,1,0x993300);
            else obj = getBox(1,1,1,0xffffff)
            obj.castShadow = true;
            obj.position.x = i*separationMultiplier;
            obj.position.y = obj.geometry.parameters.height/2;
            obj.position.z = j*separationMultiplier;
            group.add(obj);
        }
    }
    
    group.position.x = -(separationMultiplier * (amount-1))/2;
    group.position.z = -(separationMultiplier * (amount-1))/2;

    return group;
}

function update (renderer,scene,camera,controls,clock) {
    renderer.render (scene,camera);

    var plane = scene.getObjectByName ('plane-1');
    plane.rotation.z += 0.01;
    
    controls.update();

    var timeElapsed = clock.getElapsedTime();
    var boxGrid = scene.getObjectByName('boxGrid8');
    boxGrid.children.forEach (function(child,index){
        child.scale.y = (Math.cos(timeElapsed*2+index)+1)/2 + 0.01;
        child.position.y = child.scale.y/2;
    });

    // var cameraZPosition = scene.getObjectByName('ZPos');
    // if (cameraZPosition.position.z > -15)
    //     cameraZPosition.position.z -= 0.25;
    
    requestAnimationFrame (function(){
        update (renderer,scene,camera,controls,clock);
    })
}
init();


